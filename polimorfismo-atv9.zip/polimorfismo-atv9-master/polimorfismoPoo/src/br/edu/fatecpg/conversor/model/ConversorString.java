package br.edu.fatecpg.conversor.model;

public class ConversorString {
	
	public void converter (String x) {
		System.out.println(x.toUpperCase());
	}
}
