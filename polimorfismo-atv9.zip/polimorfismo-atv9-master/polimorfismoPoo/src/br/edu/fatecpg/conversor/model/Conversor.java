package br.edu.fatecpg.conversor.model;

public class Conversor {

	
	public void converter () {
		System.out.println("Escolha uma classe");
	}
}
