package br.edu.fatecpg.pagamento.model;

public class Pagamento {

	public void processarPagamento () {
		System.out.println("Processando pagamento genérico!");
	}
	
	
	
}
