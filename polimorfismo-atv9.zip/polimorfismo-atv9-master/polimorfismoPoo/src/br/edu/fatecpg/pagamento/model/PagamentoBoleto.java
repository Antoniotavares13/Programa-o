package br.edu.fatecpg.pagamento.model;

public class PagamentoBoleto extends Pagamento{

	public void processarPagamento () {
		System.out.println("Processando pagamento via boleto bancario");
	}
	
}
