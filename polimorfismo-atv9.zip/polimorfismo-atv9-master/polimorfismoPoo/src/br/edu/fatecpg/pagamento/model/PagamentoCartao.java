package br.edu.fatecpg.pagamento.model;

public class PagamentoCartao extends Pagamento{

	public void processarPagamento () {
		System.out.println("Processando pagamento via cartão de crédito");
	}
	
}
