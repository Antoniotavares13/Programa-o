package br.edu.fatecpg.veiculo.model;

public class Bicicleta extends Veiculo{

public void mover () {
	System.out.println("A bicicleta está pedalando");	
	}
	
}
