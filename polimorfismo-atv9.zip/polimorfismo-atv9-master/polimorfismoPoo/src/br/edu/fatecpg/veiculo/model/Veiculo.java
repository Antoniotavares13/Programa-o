package br.edu.fatecpg.veiculo.model;

public class Veiculo {

	public void mover () {
		
	}
	
}
