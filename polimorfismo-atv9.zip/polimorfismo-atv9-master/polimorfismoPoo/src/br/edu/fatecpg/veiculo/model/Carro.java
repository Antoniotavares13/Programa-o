package br.edu.fatecpg.veiculo.model;

public class Carro extends Veiculo{

public void mover () {
		System.out.println("O carro está dirigindo");
	}
	
}
